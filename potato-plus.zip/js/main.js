(function ($) {
    "use strict";
    $(document).ready(function () {
        $(function () {

/* ========================================================================== */
/* =========> Toggle Menu Activate
/* ========================================================================== */
$( "#menu_toggle span" ).click(function() {
$( "#primary_nav" ).slideToggle( "slow" );
});

/* ========================================================================== */
/* =========> REVALUTION SLIDER Init
/* ========================================================================== */
          var patrev;
          patrev = jQuery('.fullwidthbanner').revolution(
          {
              delay:10000,
              startwidth:1170,
              startheight:500,
              hideThumbs:10,
              onHoverStop:"off",
              fullWidth:"off",
              fullScreen:"on",
              navigationType:"none",
              fullScreenOffsetContainer: ""
          });

/* ========================================================================== */
/* =========> Isotopy with masonary grid
/* ========================================================================== */
        $(window).load(function(){
          var $container = $('#container'),
            colWidth = function () {
              var w = $container.width(), 
                columnNum = 1,
                columnWidth = 0;
              if (w > 1200) {
                columnNum  = 4;
              } else if (w > 900) {
                columnNum  = 4;
              } else if (w > 600) {
                columnNum  = 3;
              } else if (w > 300) {
                columnNum  = 2;
              }
              columnWidth = Math.floor(w/columnNum);
              $container.find('.item').each(function() {
                var $item = $(this),
                  multiplier_w = $item.attr('class').match(/item-w(\d)/),
                  multiplier_h = $item.attr('class').match(/item-h(\d)/),
                  width = multiplier_w ? columnWidth*multiplier_w[1] : columnWidth,
                  height = multiplier_h ? columnWidth*multiplier_h[1]*0.3-4 : columnWidth*0.5-4;
                $item.css({
                  width: width,
                  height: height
                });
              });
              return columnWidth;
            },
            isotope = function () {
              $container.isotope({
                resizable: false,
                itemSelector: '.item',
                masonry: {
                  columnWidth: colWidth(),
                  gutterWidth: 4
                }
              });
            };
          isotope();
          $(window).smartresize(isotope);
          var $optionSets = $('#options .option-set'),
              $optionLinks = $optionSets.find('a');
          $optionLinks.click(function(){
          var $this = $(this);
            var $optionSet = $this.parents('.option-set');
            $optionSet.find('.selected').removeClass('selected');
            $this.addClass('selected');

            // make option object dynamically, i.e. { filter: '.my-filter-class' }
            var options = {},
                key = $optionSet.attr('data-option-key'),
                value = $this.attr('data-option-value');
            // parse 'false' as false boolean
            value = value === 'false' ? false : value;
            options[ key ] = value;
            if ( key === 'layoutMode' && typeof changeLayoutMode === 'function' ) {
              // changes in layout modes need extra logic
              changeLayoutMode( $this, options )
            } else {
              // creativewise, apply new options
              $container.isotope( options );
            }
            return false;
          }); 
        });

/* ========================================================================== */
/* =========> Number Animation when scoll
/* ========================================================================== */
        $('.num').appear();
        $(document.body).on('appear', '.numeric', function () {
            $('.num').each(function () {
                $(this).animateNumbers($(this).attr("data-value"), true, parseInt($(this).attr("data-animation-duration")));
            });
        });

        $.fn.animateNumbers = function (stop, commas, duration, ease) {
        return this.each(function () {
        var $this = $(this);
        var start = parseInt($this.text().replace(/,/g, ""));
        commas = (commas === undefined) ? true : commas;
        $({
            value: start
        }).animate({
                value: stop
            }, {
                duration: duration == undefined ? 500 : duration,
                easing: ease == undefined ? "swing" : ease,
                step: function () {
                    $this.text(Math.floor(this.value));
                    if (commas) {
                        $this.text($this.text().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,"));
                    }
                },
                complete: function () {
                    if (parseInt($this.text()) !== stop) {
                        $this.text(stop);
                        if (commas) {
                            $this.text($this.text().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,"));
                        }
                    }
                }
            });
        });
        };

/* ========================================================================== */
/* =========> Menu Click aprear area and smooth scroll init
/* ========================================================================== */
      var lastId,
        topMenu = $("#top-menu"),
        topMenuHeight = topMenu.outerHeight()+110,
        // All list items
        menuItems = topMenu.find("a"),
        // Anchors corresponding to menu items
        scrollItems = menuItems.map(function(){
          var item = $($(this).attr("href"));
          if (item.length) { return item; }
        });

      // so we can get a fancy scroll animation
      menuItems.click(function(e){
        var href = $(this).attr("href"),
            offsetTop = href === "#" ? 0 : $(href).offset().top-88;
        $('html, body').stop().animate({ 
            scrollTop: offsetTop,
        }, 500, 'easeInExpo');
        e.preventDefault();
      });

      // Bind to scroll
      $(window).scroll(function(){
         // Get container scroll position
         var fromTop = $(this).scrollTop()+topMenuHeight;
         
         // Get id of current scroll item
         var cur = scrollItems.map(function(){
           if ($(this).offset().top < fromTop)
             return this;
         });
         // Get the id of the current element
         cur = cur[cur.length-1];
         var id = cur && cur.length ? cur[0].id : "";
         
         if (lastId !== id) {
             lastId = id;
             // Set/remove active class
             menuItems
               .parent().removeClass("active")
               .end().filter("[href=#"+id+"]").parent().addClass("active");
         }                   
      });

/* ========================================================================== */
/* =========> Fixed menu when scroll init
/* ========================================================================== */
      $(window).scroll(function(){
        var stickyfoulx = $('.scroll_mouse').offset().top;
         if ($(window).scrollTop() > stickyfoulx){
      $("#potato_header_area").addClass("stick"); 
      } else {
           $("#potato_header_area").removeClass("stick"); 
      }
      });

/* ========================================================================== */
/* =========> Click To Top
/* ========================================================================== */
      $(window).scroll(function(){
        var stickyfoulx = $('#potato_purchese_area').offset().top;
         if ($(window).scrollTop() > stickyfoulx){
      $("#back_to_top").addClass("show_top"); 
      } else {
           $("#back_to_top").removeClass("show_top"); 
      }
      });

      $('#back_to_top').click(function(e){
        $('html, body').stop().animate({ 
            scrollTop:0,
        }, 500, 'easeInExpo');
        e.preventDefault();
      });

/* ========================================================================== */
/* =========> Owl Slider Init
/* ========================================================================== */
      var owl;
      owl = $("#potato_carousel");

      owl.owlCarousel({
        navigation: false, // Show next and prev buttons
        slideSpeed: 300,
        paginationSpeed: 400,
        singleItem: true,
        autoPlay: true,
        afterInit: customOWLpagination // do some work after OWL init
      });


      function customOWLpagination() {
      // adding A to div.owl-page
      $('.owl-controls .owl-page').append('<a class="item-link" href="#"/>');
      var pafinatorsLink = $('.owl-controls .item-link');
      $.each(this.owl.userItems, function (i) {
          $(pafinatorsLink[i])
              // i - counter
              // Give some styles and set background image for pagination item
              .css({
                  'background': 'url(' + $(this).find('.person').attr('src') + ') center center no-repeat',
                  '-webkit-background-size': 'cover',
                  '-moz-background-size': 'cover',
                  '-o-background-size': 'cover',
                  'background-size': 'cover'
              })
              // set Custom Event for pagination item
              .click(function () {
                  owl.trigger('owl.goTo', i);
              });

      });
      $('.item-link').click(function (e) {
          e.preventDefault();
      });
      }

      var owl2;
      owl2 = $("#client_list");
      owl2.owlCarousel({
        items : 4,
        itemsDesktop : [1199,4],
        itemsDesktopSmall : [979,2],
        pagination: false,
        navigation: false
      });

      var owl5;
      owl5 = $("#team_slider");
      owl5.owlCarousel({
        items : 3,
        navigationText : ['<i class="fa fa-angle-left"></i>','<i class="fa fa-angle-right"></i>'],
        itemsDesktop : [1199,3],
        itemsDesktopSmall : [979,3],
        itemsTablet: [600,2], 
        itemsMobile : [480,1],
        pagination: false,
        navigation: true
      });

  var owl7;
      owl7 = $("#potato_twitter");
      owl7.owlCarousel({
        items : 1,
        autoPlay : 5000,
        itemsDesktop : [1199,1],
        itemsDesktopSmall : [979,1],
        itemsTablet: [600,1], 
        itemsMobile : [480,1],
        pagination: true,
        navigation: false
      });

/* ========================================================================== */
/* =========> Click and Smooth Scroll
/* ========================================================================== */
      $('.scroll_mouse a, .footer_logo a, .buy_theme_btn a').click(function(e){
        var href = $(this).attr("href"),
            offsetTop = href === "#" ? 0 : $(href).offset().top-104;
        $('html, body').stop().animate({ 
            scrollTop: offsetTop,
        }, 500, 'easeInExpo');
        e.preventDefault();
      });

/* ========================================================================== */
/* =========> jQuery MagnificPopUp INIT
/* ========================================================================== */
      var gal;
      gal = $('.team_hover');
      gal.magnificPopup({
        type:'inline',
        midClick: true 
      });


/* ========================================================================== */
/* =========> jQuery MagnificPopUp INIT
/* ========================================================================== */
      $('.scroll_mouse a, .footer_logo a, .buy_theme_btn a').click(function(e){
        var href = $(this).attr("href"),
            offsetTop = href === "#" ? 0 : $(href).offset().top-104;
        $('html, body').stop().animate({ 
            scrollTop: offsetTop,
        }, 500, 'easeInExpo');
        e.preventDefault();
      });

/*****************************************/

$(document).ready(function(){
  jQuery('#container .item').hover(function(){
    $(this).addClass('gallery-active').siblings().removeClass('gallery-active');
      $('.selected').removeClass('gallery-active'); // remove all current selections
      $(this).addClass('gallery-active');
  });
});


$("#controller_close, .control_trigger").click(function (e) {
  e.preventDefault();
  if ($(".control_trigger").is(":visible")) {
     
      $(".control_trigger").animate({
          "margin-left": "-500px"
      }, 500, function () {
          $(this).hide();
      });
      
      $(".pixiefy_control_panel").animate({
          "margin-left": "0px"
      }, 500).show();
  } else {
      $(".pixiefy_control_panel").animate({
          "margin-left": "-500px"
      }, 500, function () {
          $(this).hide();
      });
      $(".control_trigger").show().animate({
          "margin-left": "0"
      }, 500);
  }
});











      });
    });
})(jQuery);



/* ========================================================================== */
/* =========> GOOGLE MAP API INIT
/* ========================================================================== */
function initialize() {
    var image = 'https://dl.dropboxusercontent.com/u/156143134/marker.png';
    var myLatlng = new google.maps.LatLng(41.850033, -87.6500523);
    var mapOptions = {
        zoom: 15,
        scrollwheel: false,
        navigationControl: false,
        mapTypeControl: false,
        scaleControl: false,
        draggable: true,
        center: myLatlng
    };

    var map = new google.maps.Map(document.getElementById('map_canvas'), mapOptions);

    var contentString = '<div id="content">' +
        '<div id="myDiv">' +
        '</div>' +
        '<h3 id="heading">COLORADO</h3>' +
        '<div id="bodyContent">' +
        '<p>PIXIEFY THEMES ' +
        '2746 Scheuvront Drive ' +
        '<a href="#">www.pixiefy.com </a>' +
        'Denver, CO 80202 . </p>' +
        '</div>' +
        '</div>';

    var infowindow = new google.maps.InfoWindow({
        content: contentString,
        maxWidth: 280
    });


    var marker = new google.maps.Marker({
        position: myLatlng,
        map: map,
        icon: image,
        animation: google.maps.Animation.DROP,
        title: 'Local Address'
    });

    marker.setAnimation(google.maps.Animation.BOUNCE);
    setTimeout(function(){ marker.setAnimation(null); }, 750);  //time it takes for one bounce   

    google.maps.event.addListener(marker, 'click', function () {
        infowindow.open(map, marker);
    });

}

google.maps.event.addDomListener(window, 'load', initialize);


/* ========================================================================== */
/* =========> jQuery WOW ANIMATION INIT
/* ========================================================================== */
var ww = $(window).width();
if(ww > 480){
    wow = new WOW({
        animateClass: 'animated',
        offset: 0
    });
    wow.init();
}


var ww = $(window).width();
if(ww < 767){
  if ($('#menu_toggle:not(:hidden)')) {    // you get the idea...
    $('nav#primary_nav ul li a').click(function (e) {
        $('#primary_nav').hide();
    });
}
}

//============================================================================== */
//* Contact Form init
//============================================================================== */
jQuery(document).ready(function(){
    $('#contact').submit(function(){
        var action = $(this).attr('action');
        $("#message").slideUp(750,function() {
        $('#message').hide();
        $('#submit')
            .addClass('button_animation')
            .attr('disabled','disabled');
        $.post(action, {
            name: $('#name').val(),
            email: $('#email').val(),
            subject: $('#subject').val(),
            comments: $('#comments').val(),
        },
            function(data){
                document.getElementById('message').innerHTML = data;
                $('#message').slideDown('slow');
                $('#contact img.contact-loader').removeClass('button_animation',function(){$(this).remove()});
                $('#submit').removeAttr('disabled');
                if(data.match('success') != null) $('#contact').slideUp('slow');
            }
        );
        });
        return false;
    });
});
